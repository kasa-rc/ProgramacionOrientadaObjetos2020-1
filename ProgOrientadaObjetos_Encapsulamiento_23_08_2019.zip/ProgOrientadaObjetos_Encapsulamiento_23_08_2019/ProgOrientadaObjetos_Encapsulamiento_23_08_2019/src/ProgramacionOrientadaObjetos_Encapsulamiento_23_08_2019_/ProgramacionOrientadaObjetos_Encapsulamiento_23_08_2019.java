/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProgramacionOrientadaObjetos_Encapsulamiento_23_08_2019_;

import poo.Persona;
import poo.Escuela;
import poo.Mochila;
import poo.Celular;
import poo.Vestido;
import poo.BotellaTekila;
import poo.Planta;
import poo.Carro;
import poo.Libro;
import poo.Pintura;
import poo.Credencial;
import poo.Pasaporte;
import poo.TicketCompra;
import poo.Zapato;
import poo.Chicle;
import poo.Elemento;
import poo.Basquetbol;
import poo.Cancion;
import poo.Calculadora;
import poo.Casa;

/**
 *
 * @author CRUZLEIJA
 */
public class ProgramacionOrientadaObjetos_Encapsulamiento_23_08_2019 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

	        Persona beto = new Persona();
	beto.setNombre("Alberto");
        System.out.println(beto.getNombre());
        beto.setEdad(17);
        System.out.println(beto.getEdad());
        beto.setEstatura(1.50);
        System.out.println(beto.getEstatura());
       
        	Escuela pOLI = new Escuela();
        pOLI.setNombre("UPIIZ");
        System.out.println(pOLI.getNombre());
        pOLI.setMatricula(17987678);
        System.out.println(pOLI.getMatricula());
        pOLI.setArea(178.50);
        System.out.println(pOLI.getArea());
	
		Mochila ross = new Mochila();
	ross.setMarca("Nike");
        System.out.println(ross.getMarca());
        ross.setCompartimentos(13);
        System.out.println(ross.getCompartimentos());
        ross.setPrecio(980.50);
        System.out.println(ross.getPrecio());
     
		Celular lG = new Celular();
        lG.setMarca("Nokia");
        System.out.println(lG.getMarca());
        lG.setApp(18);
        System.out.println(lG.getApp());
        lG.setMemoria(16.09);
        System.out.println(lG.getMemoria());
             	
		Vestido lov = new Vestido();
        lov.setMarca("ciryus");
        System.out.println(lov.getMarca());
        lov.setTalla(15);
        System.out.println(lov.getTalla());
        lov.setLargo(1.30);
        System.out.println(lov.getLargo());

            BotellaTekila agave = new BotellaTekila();
        agave.setNombre("Champang cero");
        System.out.println(agave.getNombre());        
        
		Planta verde = new Planta();
	verde.setNombre("Lilis");
        System.out.println(verde.getNombre());
        verde.setColor("Morado");
        System.out.println(verde.getColor());
        verde.setTextura("Suave");
        System.out.println(verde.getTextura());
	
		Carro estandar = new Carro();
	estandar.setModelo("LG");
        System.out.println(estandar.getModelo());
        estandar.setAño(1789);
        System.out.println(estandar.getAño());
        estandar.setColor("Negro");
        System.out.println(estandar.getColor());

		Libro novela = new Libro();
	novela.setAutor("Alberto Rojas");
        System.out.println(novela.getAutor());
        novela.setAñoEd(1987);
        System.out.println(novela.getAñoEd());
        novela.setTitulo("Salvando el hoy");
        System.out.println(novela.getTitulo());

		Pintura realismo = new Pintura();
	realismo.setEstilo("Acuarela");
        System.out.println(realismo.getEstilo());
	realismo.setAño(1977);
        System.out.println(realismo.getAño());
	realismo.setNombre("invierno en Abril");
        System.out.println(realismo.getNombre());
  
		Credencial elector = new Credencial();
	elector.setNombre("Julia");
        System.out.println(elector.getNombre());
	elector.setCURP("TGJL197778SXERTY");
        System.out.println(elector.getCURP());
        elector.setDireccion("Av. Universidad");
        System.out.println(elector.getDireccion());

		Pasaporte doc = new Pasaporte();
        doc.setNombre("Aranda");
	System.out.println(doc.getNombre());
        doc.setEdad(17);
	System.out.println(doc.getEdad());
        doc.setNacionalidad("Argentino");
	System.out.println(doc.getNacionalidad());

		TicketCompra ticket = new TicketCompra();
        ticket.setConcepto("Acuarelas");
	System.out.println(ticket.getConcepto());
        ticket.setCantidad(2);
	System.out.println(ticket.getCantidad());
        ticket.setPrecio(658.99);
	System.out.println(ticket.getPrecio());

		Zapato nike = new Zapato();
        nike.setMarca("nike");
	System.out.println(nike.getMarca());
        nike.setColor("Rojo");
	System.out.println(nike.getColor());
        nike.setTalla(5.5);
	System.out.println(nike.getTalla());

		Chicle bomba = new Chicle();
        bomba.setSabor("fresa");
	System.out.println(bomba.getSabor());
        bomba.setColor("rosa");
	System.out.println(bomba.getColor());
        bomba.setMasa(0.76);
	System.out.println(bomba.getMasa());

		Elemento tabla = new Elemento();
        tabla.setNombre("Nitrogeno");
	System.out.println(tabla.getNombre());
        tabla.setNumeroAtomico(44);
	System.out.println(tabla.getNumeroAtomico());
        tabla.setMasaAtomica(0.76);
 	System.out.println(tabla.getMasaAtomica());

            Basquetbol torneo = new Basquetbol();
        torneo.setNombreEquipo("Loro");
        System.out.println(torneo.getNombreEquipo());
        torneo.numeroJugador = 4;
        torneo.puntos = 26;
        
            Cancion cover = new Cancion();
        cover.setNombre("mareas");
        System.out.println(cover.getNombre());
        cover.setNumeroLista(14);
        System.out.println(cover.getNumeroLista());
        cover.setDuracion(3.4);
        System.out.println(cover.getDuracion());
        
            Calculadora cientifica = new Calculadora();
        cientifica.setMarca("Pintaform");
        System.out.println(cientifica.getMarca());
        cientifica.setNumero(94);
        System.out.println(cientifica.getNumero());
        cientifica.setPI(3.1416);
        System.out.println(cientifica.getPI());

 		Casa we = new Casa();
        we.setColor("verde");
	System.out.println(we.getColor());
        we.setNumero(34);
	System.out.println(we.getNumero());
        we.setArea(26);
	System.out.println(we.getArea());

	System.out.println(); /*para depurar*/
    }
}
