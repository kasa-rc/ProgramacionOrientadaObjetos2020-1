/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class Credencial{
    
    private String nombre ;
    private String CURP;
    private String direccion;

    public Credencial (){
    nombre = "Descinicido";
    CURP = "Desconocido";
    direccion = "Desconocido";
    }
    
    public Credencial (String nombre, String CURP, String direccion){
    this.nombre = nombre;
    this.CURP = CURP;
    this.direccion = direccion;
    } 
    

    
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }



    
    /**
     * @return the CURP
     */
    public String getCURP() {
        return CURP;
    }

    /**
     * @param CURP the CURP to set
     */
    public void setCURP(String CURP) {
        this.CURP = CURP;
    }



    
    /**
     * @return the direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @param direccion the direccion to set
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
} 
