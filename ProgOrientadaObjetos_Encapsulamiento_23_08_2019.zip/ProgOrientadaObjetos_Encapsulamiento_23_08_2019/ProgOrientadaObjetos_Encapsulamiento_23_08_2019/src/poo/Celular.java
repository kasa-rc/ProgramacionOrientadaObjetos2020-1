/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class Celular {
    
    private String marca;
    private int app;
    private double memoria;

    public Celular (){
    marca ="Desconocido";
    app = 0;
    memoria = 0;
    }
    
    public Celular (String marca, int app, double memoria){
    this.marca = marca;
    this.app = app;
    this.memoria = memoria;
    } 
     /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }



    /**
     * @return the app
     */
    public int getApp() {
        return app;
    }

    /**
     * @param app the app to set
     */
    public void setApp(int app) {
        this.app = app;
    }



    /**
     * @return the memoria
     */
    public double getMemoria() {
        return memoria;
    }

    /**
     * @param memoria the memoria to set
     */
    public void setMemoria(double memoria) {
        this.memoria = memoria;
    }    
}