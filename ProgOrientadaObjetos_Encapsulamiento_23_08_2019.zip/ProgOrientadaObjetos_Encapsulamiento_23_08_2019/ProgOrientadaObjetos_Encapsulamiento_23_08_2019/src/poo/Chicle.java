/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class Chicle{
    
    private String sabor;
    private String color;
    private double masa;

    public Chicle (){
    sabor = "Desconocido";
    color = "Desconocido";
    masa= 0;
    }
    
    public Chicle (String sabor, String color, double masa){
    this.sabor = sabor;
    this.color = color;
    this.masa = masa;
    } 
    /**
     * @return the sabor
     */
    public String getSabor() {
        return sabor;
    }

    /**
     * @param sabor the sabor to set
     */
    public void setSabor(String sabor) {
        this.sabor = sabor;
    }



    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }



    /**
     * @return the masa
     */
    public double getMasa() {
        return masa;
    }

    /**
     * @param masa the masa to set
     */
    public void setMasa(double masa) {
        this.masa = masa;
    }

    
} 

