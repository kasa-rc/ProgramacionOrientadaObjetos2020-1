/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class Libro{
    
    private String autor ;
    private int añoEd;
    private String titulo;

    public Libro (){
    autor ="Desconocido";
    añoEd = 0;
    titulo = "Desconocido";
    }
    
    public Libro (String autor, int añoEd, String titulo){
    this.autor = autor;
    this.añoEd = añoEd;
    this.titulo = titulo;
    }     
    /**
     * @return the autor
     */
    public String getAutor() {
        return autor;
    }

    /**
     * @param autor the autor to set
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }



    /**
     * @return the añoEd
     */
    public int getAñoEd() {
        return añoEd;
    }

    /**
     * @param añoEd the añoEd to set
     */
    public void setAñoEd(int añoEd) {
        this.añoEd = añoEd;
    }



    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
} 