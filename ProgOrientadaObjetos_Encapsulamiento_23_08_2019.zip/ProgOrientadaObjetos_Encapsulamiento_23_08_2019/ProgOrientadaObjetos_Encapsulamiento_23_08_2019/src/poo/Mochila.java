/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class Mochila {
    
    private String marca;
    private int compartimentos;
    private double precio;

    public Mochila (){
    marca ="E";
    compartimentos = 0;
    precio = 0;
    }
    
    public Mochila (String marca, int compartimentos, double precio){
    this.marca = marca;
    this.compartimentos = compartimentos;
    this.precio = precio;
    }     
    
     /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }




    /**
     * @return the compartimentos
     */
    public int getCompartimentos() {
        return compartimentos;
    }

    /**
     * @param compartimentos the compartimentos to set
     */
    public void setCompartimentos(int compartimentos) {
        this.compartimentos = compartimentos;
    }




    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }
} 
