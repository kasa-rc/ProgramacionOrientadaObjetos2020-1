/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class Cancion {
    
    private String nombre;
    private int numeroLista;
    private double duracion;

    public Cancion() {
    }

    public Cancion(String nombre, int numeroLista, double duracion) {
        this.nombre = nombre;
        this.numeroLista = numeroLista;
        this.duracion = duracion;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the numeroLista
     */
    public int getNumeroLista() {
        return numeroLista;
    }

    /**
     * @param numeroLista the numeroLista to set
     */
    public void setNumeroLista(int numeroLista) {
        this.numeroLista = numeroLista;
    }

    /**
     * @return the duracion
     */
    public double getDuracion() {
        return duracion;
    }

    /**
     * @param duracion the duracion to set
     */
    public void setDuracion(double duracion) {
        this.duracion = duracion;
    }
   
} 

