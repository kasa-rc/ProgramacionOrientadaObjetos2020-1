/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */
public class TicketCompra{
    
    private String concepto ;
    private int cantidad;
    private double precio;

    public TicketCompra (){
    concepto = "Desconicido";
    cantidad = 0;
    precio = 0.0;
    }
    
    public TicketCompra (String concepto, int cantidad, double precio){
    this.concepto = concepto;
    this.cantidad = cantidad;
    this.precio = precio;
    }    

    /**
     * @return the concepto
     */
    public String getConcepto() {
        return concepto;
    }

    /**
     * @param concepto the concepto to set
     */
    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }




    /**
     * @return the cantidad
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * @param cantidad the cantidad to set
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }




   /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio ) {
        this.precio = precio;
    }
} 

