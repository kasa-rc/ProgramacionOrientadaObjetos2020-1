/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author Alumno
 */

public class Elemento{
    
    private String nombre;
    private int numeroAtomico;
    private double masaAtomica;

    public Elemento (){
    nombre = "Desconocido";
    numeroAtomico = 0;
    masaAtomica= 0;
    }
    
    public Elemento (String nombre, int numeroAtomico, double masaAtomica){
    this.nombre = nombre;
    this.numeroAtomico = numeroAtomico;
    this.masaAtomica = masaAtomica;
    }
    
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    } 
    


    /**
     * @return the numeroAtomico
     */
    public int getNumeroAtomico() {
        return numeroAtomico;
    }

    /**
     * @param numeroAtimico the numeroAtomico to set
     */
    public void setNumeroAtomico(int numeroAtomico) {
        this.numeroAtomico = numeroAtomico;
    }



     /**
     * @return the masaAtomica
     */
    public double getMasaAtomica() {
        return masaAtomica;
    }

    /**
     * @param masaAtomica the masaAtomica to set
     */
    public void setMasaAtomica(double masaAtomica) {
        this.masaAtomica = masaAtomica;
    } 

} 