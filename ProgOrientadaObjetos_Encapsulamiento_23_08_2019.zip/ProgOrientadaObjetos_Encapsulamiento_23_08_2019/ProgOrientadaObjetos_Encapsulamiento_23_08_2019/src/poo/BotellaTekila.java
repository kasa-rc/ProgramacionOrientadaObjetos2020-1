/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;
/**
 *
 * @author Alumno
 */
public class BotellaTekila {
    
    private String nombre;
    private int año;
    private double cantidad;

    public BotellaTekila(){
    nombre ="Desconocido";
    año = 0;
    cantidad = 0;
    }

    public BotellaTekila(String nombre, int año, double cantidad) {
        this.nombre = nombre;
        this.año = año;
        this.cantidad = cantidad;
    }
    
    public String getNombre(){
        return nombre;
    }
    /**
     *
     * @param nombre
     */
    public void setNombre(String nombre) { 
        this.nombre = nombre;
    }   
    
    public int getAño(){
        return año;
    }
    /**
     *
     * @param año
     */
    public void setAño(int año) { 
        this.año = año;
    } 
    
    public double getCantidad(){
        return cantidad;
    }
    /**
     *
     * @param cantidad
     */
    public void setCantidad(double cantidad) { 
        this.cantidad = cantidad;
    }    
} 
